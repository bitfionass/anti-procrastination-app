App({
  onLaunch() {
    // 检查连续天数
    const stats = wx.getStorageSync('stats') || { totalCompleted: 0, streak: 0, todayCompleted: 0, lastActiveDate: null };
    const today = this.today();
    if (stats.lastActiveDate !== today) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      if (stats.lastActiveDate !== yesterday) {
        stats.streak = 0;
        stats.todayCompleted = 0;
      }
    }
    wx.setStorageSync('stats', stats);
  },
  today() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }
});