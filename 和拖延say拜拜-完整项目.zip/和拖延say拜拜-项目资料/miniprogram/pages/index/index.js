// pages/index/index.js
// 和拖延say拜拜 - 微信小程序主逻辑

// ===== Mock AI 引擎（内联）=====
const TEMPLATES = {
  论文: {
    keywords: ['论文', '报告', '文章', '写作', '写一篇', '课程论文'],
    steps: {
      easy: ['确定论文主题和方向','搜索3-5篇参考文献','列出论文大纲','写出引言初稿','完成文献综述','撰写主体论证','写结论总结','检查格式和引用','通读全文修改'],
      medium: ['确定主题写研究问题','搜集10篇+参考文献','设计论文结构','完成引言部分','文献综述按主题梳理','研究方法章节','主体论证3-4个论点','结论+局限+展望','格式调整','全文校对查重'],
      hard: ['深度调研选题确认创新点','系统文献检索20篇+','建立文献矩阵表','设计研究框架','撰写研究方法','数据收集/案例分析','结果呈现图表+文字','讨论对比+解释+启示','撰写中英文摘要','全文校对查重']
    }
  },
  复习: {
    keywords: ['复习', '考试', '备考', '期末', '期中', '考研'],
    steps: {
      easy: ['整理课堂笔记','制作思维导图','做2套练习题','标记错题知识点','重点复习错题','模拟自测'],
      medium: ['梳理全部知识点清单','每章制作思维导图','整理笔记+补充课本','按章节做练习题','建立错题本分析','做2套完整真题计时','薄弱章节重点突破','考前模拟检验'],
      hard: ['制定详细复习计划','第一轮通读标记重点','制作详细知识框架图','第二轮精读+做笔记','每章配套练习错题记录','第三轮专题突破','做3套以上真题计时','错题回顾查漏补缺','考前冲刺只看错题','考试当天轻松回顾']
    }
  },
  小组: {
    keywords: ['小组', '团队', '合作', '汇报', '展示', 'PPT'],
    steps: {
      easy: ['和组员讨论分工','完成自己负责部分','发给组长汇总','检查内容一致性','准备提交'],
      medium: ['组内讨论确定主题框架','明确分工和截止时间','搜集资料','完成内容撰写','组内交叉审核','制作PPT排版','组内彩排预演','提交汇报'],
      hard: ['头脑风暴确定选题','制定时间表和里程碑','分工进行资料调研','各自完成子模块初稿','线上协作整合统一风格','制作高质量PPT','撰写汇报稿要点','组内排练2次修改','最终彩排技术检查','正式汇报提交']
    }
  },
  技能: {
    keywords: ['学习', '技能', '入门', '教程', '自学', '编程', '画画'],
    steps: {
      easy: ['找一个入门教程','看完基础部分','跟着动手做一遍','自己做个小练习','总结学到的内容'],
      medium: ['搜集3个优质学习资源','制定学习计划','学习基础概念术语','跟着教程做练习','每天练习记录进步','完成一个小项目','找人给反馈改进'],
      hard: ['调研学习路径','选择核心学习资源','基础理论1-2周','跟着教程做3个小练习','独立完成1个小项目','找社区交流反馈','做1个有挑战的项目','整理笔记写总结','制定长期练习计划']
    }
  },
  整理: {
    keywords: ['整理', '收拾', '打扫', '清洁', '房间', '桌面', '衣柜'],
    steps: {
      easy: ['分成要和不要两类','不要的收起来','要的归位','简单擦拭','检查效果'],
      medium: ['拍照记录整理前状态','清空目标区域','分类保留/丢弃/捐赠','清洁空出的区域','按使用频率归位','贴标签记录位置','处理丢弃物品'],
      hard: ['制定分区+时间计划','准备收纳工具','第一区取出→分类→清洁→归位','第二区同上','第三区同上','处理闲置物品','建立日常维护规则','拍照对比前后','设定每月检查提醒']
    }
  }
};
const GENERIC_STEPS = {
  easy: ['明确任务目标','拆成3-5个小步','从最简单的开始','完成一步检查','继续下一步'],
  medium: ['写下最终目标和验收标准','拆成5-8个具体步骤','估算每步时间','从第一步专注完成','每步标记进度','遇困难调整计划','完成后回顾总结'],
  hard: ['深度分析任务目标约束资源','制定详细执行计划','拆解为8-12个子任务','设定每个子任务截止时间','按优先级先做最难的','每天检查进度调整','关键节点阶段性检查','整合子任务成果','质量检查修改完善','最终交付复盘总结']
};
const ENCOURAGEMENTS = [
  '先做5分钟就好，开始了就成功一半了！','不用完美，先动起来就是胜利~',
  '想想完成后的成就感，冲！','一步一步来，你比想象中更厉害~',
  '最难的不是做，而是开始。你已经在开始了！','每完成一步，都是在靠近目标~',
  '别想太多，先做最小的那一步就好','你已经很棒了！'
];

function mockDecompose(input, difficulty) {
  const title = input.trim();
  if (!title) return null;
  let matched = null;
  for (const [key, tpl] of Object.entries(TEMPLATES)) {
    if (tpl.keywords.some(kw => title.includes(kw))) { matched = tpl; break; }
  }
  const rawSteps = (matched ? (matched.steps[difficulty] || matched.steps.easy) : (GENERIC_STEPS[difficulty] || GENERIC_STEPS.easy));
  const steps = rawSteps.map((text, i) => ({ id: i + 1, text, done: false, difficulty, diffLabel: {easy:'简单',medium:'中等',hard:'困难'}[difficulty] }));
  const encouragement = ENCOURAGEMENTS[Math.floor(Math.random() * ENCOURAGEMENTS.length)];
  return { title, steps, encouragement };
}

// ===== 宠物系统（内联）=====
const PET_FACES = { excited:'🤩', happy:'😊', neutral:'😐', sad:'😢', sleepy:'😴' };
const PET_SPEECHES = {
  happy: ['今天状态不错哦~','你越来越棒了！','继续加油~'],
  neutral: ['今天也要加油哦~','我相信你可以的！','一步一步来~'],
  sad: ['好久没来看我了...','要不要一起做点什么？','慢慢来就好~'],
  encourage: ['先做5分钟就好，我陪你~','别怕，你比想象中厉害！','每一步都算数！'],
  idle: ['在等你回来哦~','休息好了就继续吧~','我在这里陪你~']
};
const LEVELS = [
  {level:1,name:'小萌新',need:100,emoji:'🐣'},{level:2,name:'行动派',need:250,emoji:'🐥'},
  {level:3,name:'效率达人',need:500,emoji:'🦅'},{level:4,name:'自律王者',need:1000,emoji:'🦁'},
  {level:5,name:'传奇人物',need:2000,emoji:'🌟'}
];

function petFace(mood) {
  if (mood>=80) return PET_FACES.excited;
  if (mood>=60) return PET_FACES.happy;
  if (mood>=40) return PET_FACES.neutral;
  if (mood>=20) return PET_FACES.sad;
  return PET_FACES.sleepy;
}
function petSpeech(mood, ctx) {
  const arr = ctx==='encourage'?PET_SPEECHES.encourage:ctx==='idle'?PET_SPEECHES.idle:
    mood>=80?PET_SPEECHES.happy:mood>=60?PET_SPEECHES.happy:mood>=40?PET_SPEECHES.neutral:PET_SPEECHES.sad;
  return arr[Math.floor(Math.random()*arr.length)];
}
function getLevel(growth) {
  let cur=LEVELS[0];
  for(const l of LEVELS) { if(growth>=l.need) cur=l; else break; }
  return cur;
}
function getNextLevel(growth) {
  const cur=getLevel(growth);
  const idx=LEVELS.findIndex(l=>l.level===cur.level);
  return idx<LEVELS.length-1?LEVELS[idx+1]:null;
}
function growthPct(growth) {
  const cur=getLevel(growth), next=getNextLevel(growth);
  if(!next) return 100;
  return Math.min(100, Math.round(((growth-cur.need)/(next.need-cur.need))*100));
}

// ===== 勋章定义 =====
const BADGE_DEFS = [
  {id:'first_task',name:'起步',icon:'🌱',check:s=>s.totalCompleted>=1},
  {id:'three_tasks',name:'行动派',icon:'🏃',check:s=>s.totalCompleted>=3},
  {id:'five_tasks',name:'效率达人',icon:'⚡',check:s=>s.totalCompleted>=5},
  {id:'ten_tasks',name:'超级战士',icon:'💪',check:s=>s.totalCompleted>=10},
  {id:'streak_3',name:'三天打鱼',icon:'🔥',check:s=>s.streak>=3},
  {id:'streak_7',name:'一周坚持',icon:'🏆',check:s=>s.streak>=7},
  {id:'pet_lv2',name:'养育达人',icon:'🐾',check:s=>getLevel(s.growth||0).level>=2},
  {id:'five_today',name:'今日之星',icon:'⭐',check:s=>s.todayCompleted>=5},
];

// ===== 工具函数 =====
function today() {
  const d=new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function genId() { return Date.now().toString(36)+Math.random().toString(36).slice(2,6); }

// ===== Page =====
Page({
  data: {
    // 宠物
    petFace: '😊', petLevel: 1, petSpeech: '今天也要加油哦~',
    mood: 80, growthPct: 0, growthText: '0/100',
    // 输入
    inputValue: '', difficulty: 'easy',
    // 当前任务
    currentTask: null,
    progressPct: 0, progressDone: 0, progressTotal: 0,
    // 历史
    history: [],
    // 勋章
    badges: [],
    // 统计
    stats: { totalCompleted: 0, streak: 0, todayCompleted: 0 },
    // 倒计时
    showTimer: false, timerDisplay: '5:00', timerHint: '', timerDone: false,
    // 庆祝
    showCelebrate: false, celebrateTitle: '', celebrateMsg: '', celebrateRewards: [],
    // 内部
    _tasks: [], _currentTaskId: null, _pet: null, _badges: [], _timerInterval: null,
  },

  onLoad() {
    this._loadData();
    this._checkStreak();
    this._decayMood();
    this._renderAll();
  },

  // ===== 数据层 =====
  _loadData() {
    const tasks = wx.getStorageSync('tasks') || [];
    const pet = wx.getStorageSync('pet') || { mood:80, growth:0, lastFed:today() };
    const badges = wx.getStorageSync('badges') || [];
    const stats = wx.getStorageSync('stats') || { totalCompleted:0, streak:0, todayCompleted:0, lastActiveDate:null };
    const currentTaskId = wx.getStorageSync('currentTaskId') || null;
    this.setData({ _tasks:tasks, _pet:pet, _badges:badges, stats, _currentTaskId:currentTaskId });
  },
  _saveData() {
    wx.setStorageSync('tasks', this.data._tasks);
    wx.setStorageSync('pet', this.data._pet);
    wx.setStorageSync('badges', this.data._badges);
    wx.setStorageSync('stats', this.data.stats);
    wx.setStorageSync('currentTaskId', this.data._currentTaskId);
  },
  _checkStreak() {
    const t=today(), stats=this.data.stats;
    if(stats.lastActiveDate===t) return;
    const y=new Date(Date.now()-86400000).toISOString().split('T')[0];
    if(stats.lastActiveDate!==y){ stats.streak=0; stats.todayCompleted=0; }
    this.setData({stats});
  },
  _decayMood() {
    const pet=this.data._pet;
    if(pet.lastFed===today()) return;
    const days=Math.floor((Date.now()-new Date(pet.lastFed).getTime())/86400000);
    if(days>=1) pet.mood=Math.max(0, pet.mood-Math.min(20, days*5));
    this.setData({_pet:pet});
  },

  // ===== 渲染 =====
  _renderAll() {
    this._renderPet();
    this._renderTask();
    this._renderHistory();
    this._renderBadges();
  },
  _renderPet() {
    const pet=this.data._pet, level=getLevel(pet.growth), next=getNextLevel(pet.growth);
    this.setData({
      petFace: petFace(pet.mood),
      petLevel: level.level,
      mood: pet.mood,
      growthPct: growthPct(pet.growth),
      growthText: next?`${pet.growth}/${next.need}`:'MAX',
    });
  },
  _renderTask() {
    const task=this.data._tasks.find(t=>t.id===this.data._currentTaskId);
    if(!task){ this.setData({currentTask:null, progressPct:0, progressDone:0, progressTotal:0}); return; }
    const done=task.steps.filter(s=>s.done).length, total=task.steps.length;
    const pct=total>0?Math.round(done/total*100):0;
    const enriched = {...task, steps: task.steps.map(s=>({...s, diffLabel:{easy:'简单',medium:'中等',hard:'困难'}[s.difficulty]}))};
    this.setData({currentTask:enriched, progressPct:pct, progressDone:done, progressTotal:total});
    if(done<total) {
      const next=task.steps.find(s=>!s.done);
      if(next) this.setData({petSpeech:`下一步：${next.text}`});
    } else {
      this.setData({petSpeech:'全部完成了！你太棒了！🎉'});
    }
  },
  _renderHistory() {
    const tasks=this.data._tasks.filter(t=>t.id!==this.data._currentTaskId).slice(0,10);
    const history=tasks.map(t=>{
      const done=t.steps.filter(s=>s.done).length, total=t.steps.length;
      return {...t, completed:!!t.completedAt, progress:`${done}/${total}`};
    });
    this.setData({history});
  },
  _renderBadges() {
    const s={...this.data.stats, growth:this.data._pet.growth};
    const badges=BADGE_DEFS.map(b=>({...b, unlocked:this.data._badges.includes(b.id)}));
    this.setData({badges});
  },

  // ===== 事件 =====
  onInput(e) { this.setData({inputValue:e.detail.value}); },
  setDifficulty(e) { this.setData({difficulty:e.currentTarget.dataset.diff}); },
  useTemplate(e) {
    const map={论文:'写一篇3000字课程论文',复习:'期末考试复习',小组:'小组作业汇报准备',技能:'学习一个新技能',整理:'整理房间和桌面'};
    this.setData({inputValue:map[e.currentTarget.dataset.tpl]||''});
    this.onDecompose();
  },
  onDecompose() {
    const title=this.data.inputValue.trim();
    if(!title){ wx.showToast({title:'请输入任务',icon:'none'}); return; }
    const result=mockDecompose(title, this.data.difficulty);
    if(!result) return;
    const task={id:genId(),title:result.title,steps:result.steps,encouragement:result.encouragement,difficulty:this.data.difficulty,createdAt:new Date().toISOString(),completedAt:null};
    const tasks=[task,...this.data._tasks];
    this.setData({_tasks:tasks, _currentTaskId:task.id, inputValue:''});
    this._saveData();
    this._renderTask();
    this._renderHistory();
    this.setData({petSpeech:result.encouragement});
  },
  onRedo() { this.onDecompose(); },

  toggleStep(e) {
    const stepId=e.currentTarget.dataset.id;
    const task=this.data._tasks.find(t=>t.id===this.data._currentTaskId);
    if(!task) return;
    const step=task.steps.find(s=>s.id===stepId);
    if(!step) return;
    step.done=!step.done;
    if(step.done) this.data._pet.mood=Math.min(100, this.data._pet.mood+3);
    if(task.steps.every(s=>s.done)) this._completeTask(task);
    this._saveData();
    this._renderTask();
    this._renderPet();
  },

  _completeTask(task) {
    task.completedAt=new Date().toISOString();
    const stats=this.data.stats;
    stats.totalCompleted++; stats.todayCompleted++; stats.lastActiveDate=today();
    const growthMap={easy:15,medium:25,hard:40};
    const gained=growthMap[task.difficulty]||15;
    const oldLvl=getLevel(this.data._pet.growth).level;
    this.data._pet.growth=Math.min(9999, this.data._pet.growth+gained);
    this.data._pet.mood=Math.min(100, this.data._pet.mood+10);
    this.data._pet.lastFed=today();
    const newLvl=getLevel(this.data._pet.growth);
    const levelUp=newLvl.level>oldLvl;
    const newBadges=[];
    BADGE_DEFS.forEach(b=>{
      if(!this.data._badges.includes(b.id) && b.check({...stats,growth:this.data._pet.growth})) {
        this.data._badges.push(b.id); newBadges.push(b);
      }
    });
    this._saveData();
    const rewards=[{icon:'🍎',text:`+${gained} 成长值`},{icon:'💖',text:'+10 心情'}];
    if(levelUp) rewards.push({icon:newLvl.emoji,text:`升到 Lv.${newLvl.level}`});
    newBadges.forEach(b=>rewards.push({icon:b.icon,text:`解锁「${b.name}」`}));
    this.setData({
      showCelebrate:true, celebrateTitle:levelUp?'升级了！🎉':'太棒了！',
      celebrateMsg:`你完成了「${task.title}」！`, celebrateRewards:rewards,
      stats
    });
    this._renderPet(); this._renderBadges(); this._renderHistory();
  },

  loadTask(e) {
    this.setData({_currentTaskId:e.currentTarget.dataset.id});
    this._saveData();
    this._renderTask();
    this._renderHistory();
    wx.pageScrollTo({scrollTop:0, duration:300});
  },

  // ===== 5分钟倒计时 =====
  startTimer() {
    const task=this.data._tasks.find(t=>t.id===this.data._currentTaskId);
    if(!task) return;
    const firstUndone=task.steps.find(s=>!s.done);
    if(!firstUndone) return;
    this.setData({showTimer:true, timerDisplay:'5:00', timerHint:`专注做：${firstUndone.text}`, timerDone:false, _timerStepId:firstUndone.id});
    let seconds=300;
    this.data._timerInterval=setInterval(()=>{
      seconds--;
      const min=Math.floor(seconds/60), sec=seconds%60;
      this.setData({timerDisplay:`${min}:${String(sec).padStart(2,'0')}`});
      if(seconds<=0){
        clearInterval(this.data._timerInterval);
        this.setData({timerDisplay:'🎉',timerHint:'太棒了！5分钟到了！',timerDone:true});
        const step=task.steps.find(s=>s.id===this.data._timerStepId);
        if(step){ step.done=true; this.data._pet.mood=Math.min(100,this.data._pet.mood+5); }
        this._saveData(); this._renderTask(); this._renderPet();
      }
    },1000);
  },
  cancelTimer() {
    if(this.data._timerInterval) clearInterval(this.data._timerInterval);
    this.setData({showTimer:false});
  },
  continueAfterTimer() {
    this.setData({showTimer:false});
    const task=this.data._tasks.find(t=>t.id===this.data._currentTaskId);
    if(task && task.steps.every(s=>s.done)) this._completeTask(task);
  },
  closeCelebrate() { this.setData({showCelebrate:false}); },
});
